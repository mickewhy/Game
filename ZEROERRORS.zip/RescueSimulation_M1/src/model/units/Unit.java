package model.units;

import model.events.SOSResponder;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public class Unit implements Simulatable, SOSResponder {

	private String unitID;
	private UnitState state;
	private Address location;
	private Rescuable target;
	private int distanceToTarget;
	private int stepsPerCycle;
	private WorldListener worldListener;

	public Unit(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {

		this.unitID = unitID;
		this.location = location;
		this.stepsPerCycle = stepsPerCycle;
		this.state = UnitState.IDLE;
		this.worldListener = worldListener;

	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}

	public String getUnitID() {
		return unitID;
	}

	public Rescuable getTarget() {
		return target;
	}

	public int getStepsPerCycle() {
		return stepsPerCycle;
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public void setWorldListener(WorldListener worldListener) {
		this.worldListener = worldListener;
	}

	public void setDistanceToTarget(int distanceToTarget) {
		if (distanceToTarget <= 0) {
			this.distanceToTarget = 0;
		} else {
			this.distanceToTarget = distanceToTarget;
		}
	}

	public void cycleStep() {
		/*
		 * if(getTarget() != null && this instanceof Evacuator)
		 * getWorldListener().assignAddress(this,
		 * getTarget().getLocation().getX(), getTarget().getLocation().getY());
		 */
		if (state != UnitState.IDLE && target != null) {
			// CASE 1
			if (state == UnitState.RESPONDING) {
				if (distanceToTarget > 0)
					setDistanceToTarget(distanceToTarget - stepsPerCycle);
				// CASE 2
				else {
					worldListener.assignAddress(this, target.getLocation()
							.getX(), target.getLocation().getY());
					if (this instanceof Evacuator) {
						if (((ResidentialBuilding) target)
								.getStructuralIntegrity() == 0
								|| ((ResidentialBuilding) target)
										.getOccupants().size() == 0) {
							jobsDone();
						} else
							treat();
					} else
						treat();
				}
			}
			// CASE 3
			else if (this instanceof Evacuator) {
				if (((Evacuator) this).getPassengers().size() > 0) {
					if (((Evacuator) this).getDistanceToBase() > 0) {
						((Evacuator) this).setDistanceToBase(((Evacuator) this)
								.getDistanceToBase() - getStepsPerCycle());
					} else if (((Evacuator) this).getDistanceToBase() <= 0) {
						((Evacuator) this).setDistanceToBase(0);
						getWorldListener().assignAddress(this, 0, 0);
						setState(UnitState.RESPONDING);
						setDistanceToTarget((getTarget().getLocation().getX())
								+ (getTarget().getLocation().getY()));
						// UNLOADING
						for (int i = 0; i < ((Evacuator) this).getPassengers()
								.size(); i++) {
							if (((Evacuator) this).getPassengers().get(i)
									.getState() != CitizenState.DECEASED)
								((Evacuator) this).getPassengers().get(i)
										.setState(CitizenState.RESCUED);
							((Evacuator) this)
									.getPassengers()
									.get(i)
									.getWorldListener()
									.assignAddress(
											((Evacuator) this).getPassengers()
													.get(i), 0, 0);
						}
						((Evacuator) this).getPassengers().clear();
					}
				}
			}
			if (getTarget() != null && distanceToTarget <= 0)
				getWorldListener().assignAddress(this,
						getTarget().getLocation().getX(),
						getTarget().getLocation().getY());
		}
	}

	public void treat() {
		target.getDisaster().setActive(false);
		state = UnitState.TREATING;
	}

	public void jobsDone() {
		/*
		 * if ((target instanceof Citizen && (((Citizen) target).getHp() == 0)
		 * || ((Citizen) target) .getState().equals(CitizenState.RESCUED)) ||
		 * (target instanceof ResidentialBuilding && ((ResidentialBuilding)
		 * target) .getStructuralIntegrity() == 0)) {}
		 */
		this.target = null;
		setState(UnitState.IDLE);
	}

	public void respond(Rescuable r) {
		if ((getTarget() instanceof Citizen && getTarget() != (Citizen) r)
				|| (getTarget() instanceof ResidentialBuilding && getTarget() != (ResidentialBuilding) r)) {
			if (!(this instanceof MedicalUnit)
					|| (this instanceof MedicalUnit && !state
							.equals(UnitState.TREATING)))
				getTarget().getDisaster().setActive(true);
		}
		setState(UnitState.RESPONDING);
		target = r;
		setDistanceToTarget((Math.abs(r.getLocation().getX()
				- this.getLocation().getX()))
				+ (Math.abs(r.getLocation().getY() - this.getLocation().getY())));
	}
}
