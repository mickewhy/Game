package model.units;

import model.events.WorldListener;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;

public class Ambulance extends MedicalUnit {

	public Ambulance(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {

		super(unitID, location, stepsPerCycle, worldListener);

	}

	public void treat() {
		super.treat();
		if (getTarget() instanceof Citizen) {
			((Citizen) getTarget()).setBloodLoss(((Citizen) getTarget())
					.getBloodLoss() - this.getTreatmentAmount());
			if (((Citizen) getTarget()).getBloodLoss() == 0
					&& ((Citizen) getTarget()).getBloodLoss() == 0) {
				this.heal();
				((Citizen) getTarget()).setState(CitizenState.RESCUED);
			}
		}
		this.setState(UnitState.IDLE);
	}

	public void respond(Rescuable r) {
		if (getState() == UnitState.TREATING
				&& ((Citizen) getTarget()).getBloodLoss() != 0)
			getTarget().getDisaster().setActive(true);
		super.respond(r);
	}
}
