package model.units;

import java.util.ArrayList;

import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.events.WorldListener;
import simulation.Address;

public class Evacuator extends PoliceUnit {

	public Evacuator(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener, int maxCapacity) {

		super(unitID, location, stepsPerCycle, worldListener, maxCapacity);

	}

	public void treat() {
		getWorldListener().assignAddress(this,
				getTarget().getLocation().getX(),
				getTarget().getLocation().getY());
		ArrayList<Citizen> tmp = new ArrayList<Citizen>();
		setState(UnitState.TREATING);
		for (int i = 0; (getPassengers().size()) < getMaxCapacity()
				&& i < ((ResidentialBuilding) getTarget()).getOccupants()
						.size(); i++) {
			if (((Citizen) ((ResidentialBuilding) getTarget()).getOccupants()
					.get(i)).getHp() != 0) {
				getPassengers().add(
						(Citizen) ((ResidentialBuilding) getTarget())
								.getOccupants().get(i));
				tmp.add(((ResidentialBuilding) getTarget()).getOccupants().get(
						i));
			}
		}
		((ResidentialBuilding) getTarget()).getOccupants().removeAll(tmp);
		setDistanceToBase((Math.abs(getLocation().getX()))
				+ (Math.abs(getLocation().getY())));
		setDistanceToTarget(0);
	}
}
