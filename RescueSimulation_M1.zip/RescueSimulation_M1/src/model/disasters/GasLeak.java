package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class GasLeak extends Disaster {

	public GasLeak(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((ResidentialBuilding) getTarget())
				.setGasLevel(((ResidentialBuilding) getTarget()).getGasLevel() + 10);
	}

	public void cycleStep() {
		((ResidentialBuilding) getTarget())
				.setGasLevel(((ResidentialBuilding) getTarget()).getGasLevel() + 15);
	}

}
