package model.disasters;

import model.people.Citizen;

public class Injury extends Disaster {

	public Injury(int startCycle, Citizen target) {

		super(startCycle, target);

	}

	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((Citizen) getTarget()).setBloodLoss(((Citizen) getTarget())
				.getBloodLoss() + 30);
	}

	public void cycleStep() {
		((Citizen) getTarget()).setBloodLoss(((Citizen) getTarget())
				.getBloodLoss() + 10);
	}
}
