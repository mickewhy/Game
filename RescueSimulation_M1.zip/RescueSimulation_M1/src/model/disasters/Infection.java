package model.disasters;

import model.people.Citizen;

public class Infection extends Disaster {

	public Infection(int startCycle, Citizen target) {

		super(startCycle, target);

	}

	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((Citizen) getTarget()).setToxicity(((Citizen) getTarget())
				.getToxicity() + 25);
	}

	public void cycleStep() {
		((Citizen) getTarget()).setToxicity(((Citizen) getTarget())
				.getToxicity() + 15);
	}
}
