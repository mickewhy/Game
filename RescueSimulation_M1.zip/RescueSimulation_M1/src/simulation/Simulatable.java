package simulation;

public interface Simulatable {
	void cycleStep();
}
