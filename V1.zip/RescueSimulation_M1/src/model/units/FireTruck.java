package model.units;

import model.events.SOSResponder;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;
import simulation.Rescuable;
import model.events.*;

public class FireTruck extends FireUnit  {
	 
	public FireTruck(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {

		super(unitID, location, stepsPerCycle, worldListener);

	}

	
	public void treat() {
		super.getTarget().getDisaster().setActive(false);
		ResidentialBuilding b = (ResidentialBuilding) super.getTarget();
		b.setFireDamage(b.getFireDamage() - 10);
		this.setState(UnitState.IDLE);
	}
	

	

}
