package model.units;

import model.events.SOSResponder;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

import java.lang.annotation.Target;
import java.util.ArrayList;

import model.events.*;

public class Evacuator extends PoliceUnit {

	public Evacuator(String unitID, Address location, int stepsPerCycle, WorldListener worldListener, int maxCapacity) {

		super(unitID, location, stepsPerCycle, worldListener, maxCapacity);

	}

	public void treat() {
		ResidentialBuilding b= (ResidentialBuilding) this.getTarget();
	
		if (b.getDisaster().isActive()==false || b.getStructuralIntegrity() <= 0 ) {
		jobsDone();
		}
		else {
			if(getX()==Es.attarget) {
				for (int i = 0; i < getMaxCapacity(); i++) {
					if (b.getOccupants().size() > 0) {
						getPassengers().add(b.getOccupants().remove(0));
					}}
			}
			else {
				int k = getPassengers().size();
				for (int i = 0; i < k; i++) {
					Citizen x = getPassengers().remove(0);
					
					x.getWorldListener().assignAddress(x, 0, 0);
					x.setState(CitizenState.RESCUED);
					
				}
				if (b.getOccupants().size() == 0) {
					jobsDone();
				} 
			}
		
			
			}
		

	}

}
