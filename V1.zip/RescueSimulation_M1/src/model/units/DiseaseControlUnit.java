package model.units;

import model.events.SOSResponder;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import model.events.*;

public class DiseaseControlUnit extends MedicalUnit  {

	public DiseaseControlUnit(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {

		super(unitID, location, stepsPerCycle, worldListener);

	}
	public void respond(Rescuable r) {
		if (getState() == UnitState.TREATING &&( (Citizen)getTarget()).getToxicity() == 0) {
			getTarget().getDisaster().setActive(false);
		}
		else if (getState() == UnitState.TREATING &&( (Citizen)getTarget()).getToxicity() != 0)
			getTarget().getDisaster().setActive(true);
		super.respond(r);
		
	}

	public void treat() {
		this.getTarget().getDisaster().setActive(false);
		Citizen c = (Citizen)this.getTarget();
		if (c.getState()== CitizenState.DECEASED)
			jobsDone();
		else {
			if (c.getToxicity() == 0) {
				this.heal();
			} 
			else {
				if ((c.getToxicity() - getTreatmentAmount()) > 0) {
					c.setToxicity(c.getToxicity() - getTreatmentAmount());
				} 
				else {
						c.setToxicity(0);
						c.setState(CitizenState.RESCUED);

				}
			}

			}
		}
	
	

}
