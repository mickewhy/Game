package model.units;

public enum Es {
	totarget,tobase, attarget,atbase;

}
