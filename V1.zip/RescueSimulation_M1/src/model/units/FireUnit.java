package model.units;

import model.events.SOSResponder;
import model.events.WorldListener;
import simulation.Address;
import simulation.Rescuable;

public abstract class FireUnit extends Unit   {
	private WorldListener worldListener;
	public FireUnit(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {

		super(unitID, location, stepsPerCycle, worldListener);

	}
	
	public void respond(Rescuable r) {
		if (getState() == UnitState.TREATING) {
			getTarget().getDisaster().setActive(true);
			
		}
		super.respond(r);
	}

}
