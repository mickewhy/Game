package model.units;

import java.security.GeneralSecurityException;
import java.security.spec.RSAOtherPrimeInfo;

import model.events.SOSResponder;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public abstract class Unit implements Simulatable, SOSResponder {

	private String unitID;
	private UnitState state;
	private Address location;
	private Rescuable target;
	private int distanceToTarget;
	private int stepsPerCycle;
	private WorldListener worldListener;
	private Es x = Es.totarget;

	public Unit(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {

		this.unitID = unitID;
		this.location = location;
		this.stepsPerCycle = stepsPerCycle;
		this.state = UnitState.IDLE;
		this.worldListener = worldListener;
	}

	public void setDistanceToTarget(int distanceToTarget) {
		this.distanceToTarget = distanceToTarget;
	}

	public UnitState getState() {
		return state;
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public void setWorldListener(WorldListener worldListener) {
		this.worldListener = worldListener;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}

	public String getUnitID() {
		return unitID;
	}

	public Rescuable getTarget() {
		return target;
	}

	public int getStepsPerCycle() {
		return stepsPerCycle;
	}

	public void respond(Rescuable r) {
		state = UnitState.RESPONDING;
		target = r;

		int DeltaX = Math.abs(target.getLocation().getX() - this.location.getX());
		int DeltaY = Math.abs(target.getLocation().getY() - this.location.getY());
		distanceToTarget = DeltaX + DeltaY;

	}

	public void cycleStep() {
		if(!(this instanceof Evacuator))
		{
			if (getState()== UnitState.RESPONDING) {
				if (distanceToTarget==0) {
					setState(UnitState.TREATING);
					getWorldListener().assignAddress(this, target.getLocation().getX(), target.getLocation().getY());
					this.treat();
				}
				else {
					if(distanceToTarget- stepsPerCycle>0) {
						setDistanceToTarget(distanceToTarget-stepsPerCycle);
					}
					else {
						setDistanceToTarget(0);
					}
				}
			}
		}
		else {
			if(state==UnitState.RESPONDING || state== UnitState.TREATING) {
				if(x== Es.attarget) {
					this.setState(UnitState.TREATING);
				}
				if(x== Es.totarget || x== Es.tobase) {
					if(x==Es.totarget) {
						if(distanceToTarget-stepsPerCycle>0) {
							setDistanceToTarget(distanceToTarget-stepsPerCycle);}
						else {
							setDistanceToTarget(0);
							((Evacuator) this).setDistanceToBase(getTarget().getLocation().getX() + getTarget().getLocation().getY());
							getWorldListener().assignAddress(this, target.getLocation().getX(), target.getLocation().getY());
							x=Es.attarget;
						}
					}
					else {
						if (((Evacuator) this).getDistanceToBase() - stepsPerCycle > 0){
							((Evacuator) this).setDistanceToBase(((Evacuator) this).getDistanceToBase() - stepsPerCycle);
						}
					
					else {
						((Evacuator) this).setDistanceToBase(0);
						setDistanceToTarget(getTarget().getLocation().getX() + getTarget().getLocation().getY());
						getWorldListener().assignAddress(this, 0, 0);
						x= Es.atbase;
					}
					}
				}
				else
				{
					this.treat();
					if(x==Es.atbase) {
						x=Es.totarget;
					}
					else {
						x= Es.tobase;
					}
				}
			}
		}
		
		
		
	}

	public void treat() {
		this.setState(UnitState.TREATING);
		target.getDisaster().setActive(false);
	}

	public void jobsDone() {
		this.target = null;
		setState(UnitState.IDLE);
	}

	public Es getX() {
		return x;
	}

	public void setX(Es x) {
		this.x = x;
	}

}
