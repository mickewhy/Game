package model.units;

import simulation.Address;
import simulation.Rescuable;
import model.events.*;
import model.people.Citizen;
import model.people.CitizenState;

public class Ambulance extends MedicalUnit  {
	
	public Ambulance(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {

		super(unitID, location, stepsPerCycle, worldListener);

	}
	public void respond(Rescuable r) {
		if (getState() == UnitState.TREATING &&( (Citizen)getTarget()).getBloodLoss() == 0) {
			getTarget().getDisaster().setActive(false);
		}
		else if (getState() == UnitState.TREATING &&( (Citizen)getTarget()).getBloodLoss() != 0)
			getTarget().getDisaster().setActive(true);
		super.respond(r);
		
	}

	
	public void treat() {
		this.getTarget().getDisaster().setActive(false);
		Citizen c = (Citizen)this.getTarget();
		if (c.getState()== CitizenState.DECEASED)
			jobsDone();
		else {
			if (c.getBloodLoss() == 0) {
				this.heal();
			} 
			else {
				if ((c.getBloodLoss() - getTreatmentAmount()) > 0) {
					c.setBloodLoss(c.getBloodLoss() - getTreatmentAmount());
				} 
				else {
						c.setBloodLoss(0);
						c.setState(CitizenState.RESCUED);

				}
			}

			}
		}
	
	
	

}
