package model.people;

import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;
import model.disasters.Disaster;
import model.events.*;

public class Citizen implements Rescuable, Simulatable {

	private CitizenState state;
	private Disaster disaster;
	private String name;
	private String nationalID;
	private int age;
	private int hp;
	private int bloodLoss;
	private int toxicity;
	private Address location;
	private SOSListener emergencyService;
	private WorldListener WorldListener;

	public Citizen(Address location, String nationalID, String name, int age,WorldListener WorldListener) {

		this.name = name;
		this.nationalID = nationalID;
		this.age = age;
		this.location = location;
		this.state = CitizenState.SAFE;
		this.hp = 100;

	}

	public CitizenState getState() {
		return state;
	}

	public void setState(CitizenState state) {
		this.state = state;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
		if (this.hp >= 100)
			this.hp = 100;
		else if (this.hp <= 0) {
			this.hp = 0;
		state = CitizenState.DECEASED;
		}
	}

	public int getBloodLoss() {
		return bloodLoss;
	}

	public void setBloodLoss(int bloodLoss) {
		this.bloodLoss = bloodLoss;
		if (this.bloodLoss >= 100) {
			this.bloodLoss = 100;
			this.state = CitizenState.DECEASED;
			setHp(0);
			
		}
		else if (this.bloodLoss <0)
			this.bloodLoss = 0;
		
	}

	public int getToxicity() {
		return toxicity;
		
	}

	public void setToxicity(int toxicity) {
		this.toxicity = toxicity;
		if (toxicity > 100) {
			this.toxicity = 100;
					setHp(0);
		}
		else if (toxicity <0)
			this.toxicity = 0;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}

	public Disaster getDisaster() {
		return disaster;
	}

	public String getNationalID() {
		return nationalID;
	}

	@Override
	public void struckBy(Disaster d) {
		// TODO Auto-generated method stub
		this.disaster = d;
		this.state = CitizenState.IN_TROUBLE;
		emergencyService.receiveSOSCall(this);
	}

	public WorldListener getWorldListener() {
		return WorldListener;
	}

	public void setWorldListener(WorldListener worldListener) {
		WorldListener = worldListener;
	}

	@Override
	public void cycleStep() {
		// TODO Auto-generated method stub
		if ((bloodLoss > 0 && bloodLoss < 30) || (toxicity > 0 && toxicity < 30))
			setHp(getHp()-5);
		else if ((bloodLoss >= 30 && bloodLoss < 70) || (toxicity >=30 && toxicity < 70))
			setHp(getHp()-10);
		else if ((bloodLoss >= 70 ) || (toxicity >= 70))
			setHp(getHp()-15);
	}

	public void setEmergencyService(SOSListener emergencyService) {
		this.emergencyService = emergencyService;
	}

}
