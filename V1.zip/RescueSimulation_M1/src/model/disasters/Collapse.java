package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class Collapse extends Disaster {

	public Collapse(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		// TODO Auto-generated method stub
		if (isActive())
			((ResidentialBuilding)getTarget()).setFoundationDamage(((ResidentialBuilding)getTarget()).getFoundationDamage()+10);
	}
	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((ResidentialBuilding)getTarget()).setFoundationDamage(((ResidentialBuilding)getTarget()).getFoundationDamage()+10);
	}
}
