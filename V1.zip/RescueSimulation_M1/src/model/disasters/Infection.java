package model.disasters;

import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;

public class Infection extends Disaster {

	public Infection(int startCycle, Citizen target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		// TODO Auto-generated method stub
		if (isActive())
			((Citizen)getTarget()).setToxicity(((Citizen)getTarget()).getToxicity()+15);
	}
	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((Citizen)getTarget()).setToxicity(((Citizen)getTarget()).getToxicity()+25);
	}
}
