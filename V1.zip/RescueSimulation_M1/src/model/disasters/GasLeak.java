package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class GasLeak extends Disaster {

	public GasLeak(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		if (isActive())
			((ResidentialBuilding)getTarget()).setGasLevel(((ResidentialBuilding)getTarget()).getGasLevel()+15);	
	}
	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((ResidentialBuilding)getTarget()).setFoundationDamage(((ResidentialBuilding)getTarget()).getFoundationDamage()+10);
	}
}
