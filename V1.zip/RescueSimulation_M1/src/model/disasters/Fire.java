package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class Fire extends Disaster {

	public Fire(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		// TODO Auto-generated method stub
		if (isActive())
			((ResidentialBuilding)getTarget()).setFireDamage(((ResidentialBuilding)getTarget()).getFireDamage()+10);	
	}
	public void strike() {
		super.strike();
		getTarget().struckBy(this);
		((ResidentialBuilding)getTarget()).setFireDamage(((ResidentialBuilding)getTarget()).getFireDamage()+10);
	}
}
