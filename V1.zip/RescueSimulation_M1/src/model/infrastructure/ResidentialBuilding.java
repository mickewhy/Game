package model.infrastructure;

import java.util.ArrayList;
//import java.util.Random;

import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.events.SOSListener;
import model.events.WorldListener;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public class ResidentialBuilding implements Rescuable, Simulatable {

	private Address location;
	private int structuralIntegrity;
	private int fireDamage;
	private int gasLevel;
	private int foundationDamage;
	private ArrayList<Citizen> occupants;
	private Disaster disaster;
	private SOSListener emergencyService;

	public void setEmergencyService(SOSListener emergencyService) {
		this.emergencyService = emergencyService;
	}

	public ResidentialBuilding(Address location) {

		this.location = location;
		this.structuralIntegrity = 100;
		occupants = new ArrayList<Citizen>();

	}

	public int getStructuralIntegrity() {
		return structuralIntegrity;
	}

	public void setStructuralIntegrity(int structuralIntegrity) {
		this.structuralIntegrity = structuralIntegrity;
		if (this.structuralIntegrity <= 0) {
			this.structuralIntegrity = 0;
			for (int i = 0; i < occupants.size(); i++) {
				occupants.get(i).setHp(0);
			}
		}
		if (this.structuralIntegrity>100)
			this.structuralIntegrity=100;
	}

	public int getFireDamage() {
		return fireDamage;
	}

	public void setFireDamage(int fireDamage) {
		this.fireDamage = fireDamage;
		if (this.fireDamage < 0)
			this.fireDamage = 0;
		else if (this.fireDamage > 100)
			this.fireDamage = 100;
	}

	public int getGasLevel() {
		return gasLevel;
	}

	public void setGasLevel(int gasLevel) {
		this.gasLevel = gasLevel;
		if (this.gasLevel < 0)
			this.gasLevel = 0;
		else if (this.gasLevel > 100) {
			this.gasLevel = 100;
			for (int i = 0; i < occupants.size(); i++) {
				occupants.get(i).setHp(0);
			}
		}
	}

	public int getFoundationDamage() {
		return foundationDamage;
	}

	public void setFoundationDamage(int foundationDamage) {
		this.foundationDamage = foundationDamage;
		if (this.foundationDamage > 100)
			setStructuralIntegrity(0);
	}

	public Address getLocation() {
		return location;
	}

	public ArrayList<Citizen> getOccupants() {
		return occupants;
	}

	public Disaster getDisaster() {
		return disaster;
	}

	@Override
	public void struckBy(Disaster d) {
		// TODO Auto-generated method stub
		this.disaster = d;
		emergencyService.receiveSOSCall(this);
	}

	@Override
	public void cycleStep() {
		// TODO Auto-generated method stub
		if (foundationDamage > 0) {
			// Random r = new Random();
			// setStructuralIntegrity(getStructuralIntegrity()-(r.nextInt(6)+5));
			setStructuralIntegrity(getStructuralIntegrity() - ((int) (Math.random() * 6 + 5)));
		} else if (fireDamage > 0 && fireDamage < 30)
			setStructuralIntegrity(getStructuralIntegrity() - 3);
		else if (fireDamage >= 30 && fireDamage < 70)
			setStructuralIntegrity(getStructuralIntegrity() - 5);
		else if (fireDamage >= 70)
			setStructuralIntegrity(getStructuralIntegrity() - 7);
	}

}
